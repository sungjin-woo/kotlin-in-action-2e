package ch08.ex1_4_4_KotlinMakesNumberConversionsExplicit3

fun main() {
    println("42".toInt())
}
