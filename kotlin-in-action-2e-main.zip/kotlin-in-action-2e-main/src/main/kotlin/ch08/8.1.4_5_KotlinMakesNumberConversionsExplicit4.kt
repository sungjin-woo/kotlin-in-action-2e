package ch08.ex1_4_5_KotlinMakesNumberConversionsExplicit4

fun main() {
    println("seven".toIntOrNull())
}
