package ch08.ex1_4_3_KotlinMakesNumberConversionsExplicit2

fun main() {
    println(Int.MAX_VALUE + 1)
    println(Int.MIN_VALUE - 1)
}
