package ch08.ex1_4_6_KotlinMakesNumberConversionsExplicit5

fun main() {
    println("trUE".toBoolean())
    println("7".toBoolean())
    println(null.toBoolean())
}
