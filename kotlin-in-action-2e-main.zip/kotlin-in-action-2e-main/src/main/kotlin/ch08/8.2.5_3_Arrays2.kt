package ch08.ex2_5_3_Arrays2

fun main() {
    val letters = Array(26) { i -> ('a' + i).toString() }
}
