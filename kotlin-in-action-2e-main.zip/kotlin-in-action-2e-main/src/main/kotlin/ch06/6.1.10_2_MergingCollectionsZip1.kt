package ch06.ex1_10_2_MergingCollectionsZip1

fun main() {
    val names = listOf("Joe", "Mary", "Jamie")
    val ages = listOf(22, 31, 22, 44, 0)
    println(names zip ages)
}
