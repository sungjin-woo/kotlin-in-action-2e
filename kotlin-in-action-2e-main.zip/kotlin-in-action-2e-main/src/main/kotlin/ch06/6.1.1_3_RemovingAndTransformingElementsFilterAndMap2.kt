package ch06.ex1_1_3_RemovingAndTransformingElementsFilterAndMap2

fun main() {
    val list = listOf(1, 2, 3, 4)
    println(list.map { it * it })
}
