package ch03.ex5_3_1_MultilineTriplequotedStrings

val kotlinLogo =
    """
    | //
    |//
    |/ \
    """.trimIndent()

fun main() {
    println(kotlinLogo)
}
