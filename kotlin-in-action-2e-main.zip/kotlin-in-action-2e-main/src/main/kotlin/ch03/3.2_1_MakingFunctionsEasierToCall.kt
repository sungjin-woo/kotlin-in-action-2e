package ch03.ex2_1_MakingFunctionsEasierToCall

fun main() {
    val list = listOf(1, 2, 3)
    println(list)
}
