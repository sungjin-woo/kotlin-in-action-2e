package strings

fun String.lastChar(): Char = this.get(this.length - 1)
