package ch05.ex1_3_2_SyntaxForLambdaExpressions1

fun main() {
    { println(42) }()
}
