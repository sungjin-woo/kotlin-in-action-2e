package ch09.ex1_5_PlusTimesDivideAndMoreOverloadingBinaryArithmeticOperations4

fun main() {
    println(0x0F and 0xF0)
    // 0
    println(0x0F or 0xF0)
    // 255
    println(0x1 shl 4)
    // 16
}
