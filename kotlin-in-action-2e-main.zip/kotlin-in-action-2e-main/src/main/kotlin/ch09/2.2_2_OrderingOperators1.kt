package ch09.ex2_2_OrderingOperators1

fun main() {
    println("abc" < "bac")
    // true
}
