package ch09.ex2_2_CompoundAssignmentOperators1

fun main() {
    val numbers = mutableListOf<Int>()
    numbers += 42
    println(numbers[0])
    // 42
}
