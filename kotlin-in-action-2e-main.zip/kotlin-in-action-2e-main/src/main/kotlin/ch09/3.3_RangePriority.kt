package ch09.RangePriority

fun main() {
    val n = 9
    println(0..(n + 1))
    // 0..10

    val m = 9
    (0..m).forEach { print(it) }
    // 0123456789
}
