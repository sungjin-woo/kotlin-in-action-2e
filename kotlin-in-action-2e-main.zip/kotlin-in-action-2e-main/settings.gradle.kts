
rootProject.name = "kia-examples"

